# Copyright 2025 HOUMO AI
#
# File: version.py
# Description:
#   Version information for xh_model_zoo.
#   This module provides version parsing and information.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0
__version__ = "0.9.0"
short_version = __version__


def parse_version_info(version_str):
    version_info = []
    for x in version_str.split("."):
        if x.isdigit():
            version_info.append(int(x))
        elif x.find("rc") != -1:
            patch_version = x.split("rc")
            version_info.append(int(patch_version[0]))
            version_info.append(f"rc{patch_version[1]}")
    return tuple(version_info)


version_info = parse_version_info(__version__)
