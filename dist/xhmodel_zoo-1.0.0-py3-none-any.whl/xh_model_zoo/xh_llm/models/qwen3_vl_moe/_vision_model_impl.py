# Copyright 2025 HOUMO AI
#
# File: _vision_model_impl.py
# Description:
#   Vision Model Impl model implementation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from .modeling_qwen3moe_vl import (  
    Qwen3VLMoeVisionPatchEmbed,
    Qwen3VLMoeVisionModel,
    Qwen3VLMoeVisionAttention,
    Qwen3VLMoeVisionBlock,
    Qwen3VLMoeVisionPatchMerger,
    rotate_half,
)
from xhquant import nn as xhnn
from xhquant.api import ConfigDict
from xhquant.utils.registry import DynamicModule

from ..builder import XHLLM_TRACEABLE_MODULES


@XHLLM_TRACEABLE_MODULES.register_module(
    {
        Qwen3VLMoeVisionAttention: "Qwen3VLMoeVisionAttention",
    }
)
class _Qwen3VLMoeVisionAttention(DynamicModule):
    def apply_rotary_pos_emb(
        self, q: torch.Tensor, k: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if self.enable_rope:
            q_embed = self.rope(q, cos, sin)
            k_embed = self.rope(k, cos, sin)
        else:
            q_embed = (q * cos) + (rotate_half(q) * sin)
            k_embed = (k * cos) + (rotate_half(k) * sin)
        return q_embed, k_embed

    def _setup(self, cfg: ConfigDict):
        self.only_first_block = False

        self.enable_rope = cfg.get("enable_rope", False)
        if self.enable_rope:
            self.rope = xhnn.Rope()

        self.max_size_w = cfg.max_size_w
        self.max_size_h = cfg.max_size_h
        self.patch_size = cfg.patch_size

        head_dim = self.qkv.out_features // 3 // self.num_heads

        self.kv_scale = 1 / math.sqrt(head_dim)

        weight = self.qkv.weight.data.clone()
        bias = self.qkv.bias.data.clone()

        dim = weight.shape[0] // 3

        weight = weight.permute(1, 0).reshape(dim, 3, dim).permute(1, 2, 0)
        bias = bias.reshape(3, dim)
        self.q_proj = nn.Linear(dim, dim, bias=True)
        self.k_proj = nn.Linear(dim, dim, bias=True)
        self.v_proj = nn.Linear(dim, dim, bias=True)

        self.q_proj.weight.data = weight[0]
        self.q_proj.bias.data = bias[0]
        self.k_proj.weight.data = weight[1]
        self.k_proj.bias.data = bias[1]
        self.v_proj.weight.data = weight[2]
        self.v_proj.bias.data = bias[2]

    def forward(self, hidden_states, position_embeddings):
        batch, seq_length, _ = hidden_states.shape

        q = self.q_proj(hidden_states).reshape(batch, seq_length, self.num_heads, -1)
        k = self.k_proj(hidden_states).reshape(batch, seq_length, self.num_heads, -1)
        v = self.v_proj(hidden_states).reshape(batch, seq_length, self.num_heads, -1)
        cos, sin = position_embeddings
        cos = cos.unsqueeze(0)
        sin = sin.unsqueeze(0)
        q, k = self.apply_rotary_pos_emb(q, k, cos, sin)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        k = k.transpose(-2, -1)
        q = q * self.kv_scale
        dtype = q.dtype
        attn_weights = torch.matmul(q, k).to(dtype)
        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(dtype)
        attn_output = torch.matmul(attn_weights, v)

        attn_output = attn_output.transpose(1, 2)
        attn_output = attn_output.reshape(batch, seq_length, -1)
        attn_output = self.proj(attn_output)
        return attn_output


@XHLLM_TRACEABLE_MODULES.register_module(
    {
        Qwen3VLMoeVisionBlock: "Qwen3VLMoeVisionBlock",
    }
)
class _Qwen3VLMoeVisionBlock(DynamicModule):
    @torch.no_grad()
    def _setup(self, cfg: ConfigDict):
        pass

    def forward(self, hidden_states, position_embeddings):
        hidden_states = hidden_states + self.attn(
            self.norm1(hidden_states),
            position_embeddings=position_embeddings,
        )
        hidden_states = hidden_states + self.mlp(self.norm2(hidden_states))
        return hidden_states


def weight_denorm(
    conv2d: nn.Conv2d,
):
    norm = torch.tensor([0.5, 0.5, 0.5]).view(1, -1, 1, 1).to(conv2d.weight.device) * 255
    std = torch.tensor([0.5, 0.5, 0.5]).view(1, -1, 1, 1).to(conv2d.weight.device) * 255
    conv2d.weight.data = conv2d.weight.data / std
    bias_data = -(norm * conv2d.weight.data).sum(dim=[1, 2, 3])
    conv2d.bias = nn.Parameter(bias_data)


@XHLLM_TRACEABLE_MODULES.register_module(
    {
        Qwen3VLMoeVisionPatchEmbed: "Qwen3VLMoeVisionPatchEmbed",
    }
)
class _Qwen3VLMoeVisionPatchEmbed(DynamicModule):
    @torch.no_grad()
    def _setup(self, cfg: ConfigDict):
        self.only_first_block = False
        self.max_size_w = cfg.max_size_w
        self.max_size_h = cfg.max_size_h
        self.patch_size = cfg.patch_size

        kernel_size = [self.patch_size, self.patch_size]
        dev = self.proj.weight.device
        self.proj1 = nn.Conv2d(
            self.in_channels,
            self.embed_dim,
            kernel_size=kernel_size,
            stride=kernel_size,
            bias=False,
            device=dev,
        )
        self.proj2 = nn.Conv2d(
            self.in_channels,
            self.embed_dim,
            kernel_size=kernel_size,
            stride=kernel_size,
            bias=False,
            device=dev,
        )
        self.proj1.weight.data.copy_(self.proj.weight[:, :, 0, :, :].contiguous())
        self.proj2.weight.data.copy_(self.proj.weight[:, :, 1, :, :].contiguous())

        weight_denorm(self.proj1)
        weight_denorm(self.proj2)

        self.proj1.to(self.proj.weight.device, dtype=self.proj.weight.dtype)
        self.proj2.to(self.proj.weight.device, dtype=self.proj.weight.dtype)

        del self.proj
        assert self.temporal_patch_size == 2, "temporal_patch_size must be 2"

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        # hidden_states: [b, c, t, h, w]
        b, c, t, h, w = hidden_states.shape
        t_new = t // self.temporal_patch_size
        hidden_states = hidden_states.reshape(b, c, t_new, self.temporal_patch_size, h, w)
        hidden_states = hidden_states.permute(0, 2, 1, 3, 4, 5).reshape(b * t_new, c, self.temporal_patch_size, h, w)
        hidden_states0, hidden_states1 = hidden_states.unbind(2)
        y1 = self.proj1(hidden_states0)
        y2 = self.proj2(hidden_states1)
        hidden_states = y1 + y2
        
        _, c, h, w = hidden_states.shape
        hidden_states = hidden_states.reshape(b, t_new, c, h // 2, 2, w // 2, 2)
        hidden_states = hidden_states.permute(0, 1, 3, 5, 4, 6, 2)
        hidden_states = hidden_states.reshape(b, -1, c)
        return hidden_states


@XHLLM_TRACEABLE_MODULES.register_module(
    {
        Qwen3VLMoeVisionPatchMerger: "Qwen3VLMoeVisionPatchMerger",
    }
)
class _Qwen3VLMoeVisionPatchMerger(DynamicModule):
    def _setup(self, cfg: ConfigDict):
        pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch = x.shape[0]
        x = self.norm(x.view(batch, -1, self.hidden_size) if self.use_postshuffle_norm else x).view(batch, -1, self.hidden_size)
        x = self.linear_fc2(self.act_fn(self.linear_fc1(x)))
        return x


@XHLLM_TRACEABLE_MODULES.register_module(
    {
        Qwen3VLMoeVisionModel: "Qwen3VLMoeVisionModel",
    }
)
class _Qwen3VLMoeVisionModel(DynamicModule):
    @torch.no_grad()
    def _setup(self, cfg: ConfigDict):
        self.only_first_block = False
        self.patch_size = cfg.patch_size
        device = next(self.parameters()).device
        self.max_size_w = cfg.max_size_w
        self.max_size_h = cfg.max_size_h
        self.max_size_t = cfg.max_size_t
        self.temporal_patch_size = cfg.temporal_patch_size
        grid_size_w = self.max_size_w // self.patch_size
        grid_size_h = self.max_size_h // self.patch_size
        grid_size_t = self.max_size_t // self.temporal_patch_size
        seq_length = grid_size_t * grid_size_h * grid_size_w

        assert self.max_size_w % self.patch_size == 0, "max_size_w must be divisible by patch_size"
        assert self.max_size_h % self.patch_size == 0, "max_size_h must be divisible by patch_size"
        cu_seqlens = torch.tensor([0, seq_length]).to(device)
        self.register_buffer("cu_seqlens", cu_seqlens, persistent=False)

        grid_thw = torch.tensor([[grid_size_t, self.max_size_h // self.patch_size, self.max_size_w // self.patch_size]]).to(
            device
        )

        self.register_buffer("patch_pos_embeds", self.fast_pos_embed_interpolate(grid_thw).unsqueeze(0), persistent=False)
        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        rotary_pos_emb = rotary_pos_emb.reshape(seq_length, -1)
        emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
        cos = emb.cos().unsqueeze(-2)
        sin = emb.sin().unsqueeze(-2)

        self.register_buffer("cos", cos, persistent=False)
        self.register_buffer("sin", sin, persistent=False)


    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.patch_embed(hidden_states)
        hidden_states = hidden_states + self.patch_pos_embeds
        cos = self.cos
        sin = self.sin
        position_embeddings = (cos, sin)
        # batch, seq_len, dim = hidden_states.size()
        deepstack_feature_lists = []
        for layer_num, blk in enumerate(self.blocks):
            hidden_states = blk(hidden_states, position_embeddings=position_embeddings)
            if layer_num in self.deepstack_visual_indexes:
                deepstack_feature = self.deepstack_merger_list[self.deepstack_visual_indexes.index(layer_num)](hidden_states)
                deepstack_feature_lists.append(deepstack_feature)
        hidden_states = self.merger(hidden_states)
        return hidden_states, deepstack_feature_lists


def register_wrap_cls(hf_model):
    pass
