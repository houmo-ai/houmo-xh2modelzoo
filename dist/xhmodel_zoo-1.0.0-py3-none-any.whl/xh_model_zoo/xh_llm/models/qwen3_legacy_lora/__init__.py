# Copyright 2025 HOUMO AI
#
# File: __init__.py
# Description:
#   Qwen3 Legacy Lora module initialization.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

from .inference import Qwen3LegacyLoRAInference
from .qwen3_convert_config import Qwen3LegacyLoRAConvertConfig
from .qwen3_converter import Qwen3LegacyLoRAConverterXH2a
from .qwen3_hf_compatible import Qwen3LegacyLoRAHFCompatible

__all__ = [
    "Qwen3LegacyLoRAConvertConfig",
    "Qwen3LegacyLoRAConverterXH2a",
    "Qwen3LegacyLoRAInference",
    "Qwen3LegacyLoRAHFCompatible",
]
