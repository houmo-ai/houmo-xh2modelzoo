import math
import typing

import torch
import tqdm

from . import model_utils

# from quarot_quant import quant_utils
from .hadamard_utils import is_pow2, random_hadamard_matrix


# from fast_hadamard_transform import hadamard_transform


def bake_mean_into_conv(conv: torch.nn.Conv2d) -> None:
    """
    This function takes a convolutional layer and subtracts the means from the
    weights and biases. This will result in the convolutional layer performing
    the mean substitution which is usually done inside layernorm.
    """
    conv_dtype = conv.weight.dtype
    W_ = conv.weight.data.double()
    conv.weight.data = W_ - W_.mean(dim=0, keepdim=True)
    conv.weight.data = conv.weight.data.to(conv_dtype)
    if conv.bias is not None:
        b_ = conv.bias.data.double()
        conv.bias.data = b_ - b_.mean()
        conv.bias.data = conv.bias.data.to(conv_dtype)


def _fuse_ln_lora_a(linear: torch.nn.Module, layernorm_weight: torch.Tensor) -> None:
    """Fuse layernorm weight into LoRA A matrix (input-side scaling).

    When fusing ``y = (W + B·A) · (norm_w ⊙ x)`` into ``y = W'·x + B·A'·x``,
    the A matrix must be scaled by the same ``norm_w`` that was absorbed into W:
        A' = A ⊙ norm_w   (element-wise along input dim, broadcast over rank dim)
    """
    if not hasattr(linear, "weight_lora_a"):
        return
    if layernorm_weight is None:
        return
    lora_a = getattr(linear, "weight_lora_a")
    if lora_a is None or not isinstance(lora_a, torch.Tensor):
        return
    if lora_a.ndim < 2:
        return
    if lora_a.shape[-1] != layernorm_weight.shape[0]:
        return
    lora_dtype = lora_a.dtype
    norm_w = layernorm_weight.to(device=lora_a.device, dtype=torch.float64)
    a_ = lora_a.to(dtype=torch.float64)
    # lora_a shape: [rank, in_features];  layernorm_weight shape: [in_features]
    # Broadcast multiplication scales each input-dimension column by norm_w.
    a_ = (a_ * norm_w).to(dtype=lora_dtype)
    if "weight_lora_a" in linear._buffers:
        linear._buffers["weight_lora_a"] = a_
    else:
        setattr(linear, "weight_lora_a", a_)


def fuse_ln_linear(layernorm: torch.nn.Module, linear_layers: typing.Iterable[torch.nn.Linear]) -> None:
    """
    fuse the linear operations in Layernorm into the adjacent linear blocks.
    """
    for linear in linear_layers:
        if hasattr(linear, "weight"):
            linear_dtype = linear.weight.dtype
            W_ = linear.weight.data.double()
            linear.weight.data = (W_ * layernorm.weight.double()).to(linear_dtype)
        else:
            linear_dtype = linear.dtype
            W_ = linear.data.double()
            linear.data = (W_.transpose(1, 2) * layernorm.weight.double()).transpose(1, 2).to(linear_dtype)

        # Also fuse layernorm weight into LoRA A if present (keep_lora path).
        _fuse_ln_lora_a(linear, layernorm.weight)

        if hasattr(layernorm, "bias") and layernorm.bias is not None:
            if linear.bias is None:
                linear.bias = torch.nn.Parameter(torch.zeros(linear.out_features, dtype=torch.float64))
            linear.bias.data = linear.bias.data.double() + torch.matmul(W_, layernorm.bias.double())
            linear.bias.data = linear.bias.data.to(linear_dtype)
            layernorm.bias.zero_()


def fuse_merger_linear(layernorm: torch.nn.Module, linear_layers: typing.Iterable[torch.nn.Linear]) -> None:
    """
    fuse the linear operations in Layernorm into the adjacent linear blocks.
    """
    for linear in linear_layers:
        linear_dtype = linear.weight.dtype

        # Calculating new weight and bias
        W_ = linear.weight.data.double()
        w_o, w_i = W_.shape
        size = layernorm.weight.shape[0]
        linear.weight.data = (W_.view(w_o, -1, size) * layernorm.weight.double()).to(linear_dtype).view(w_o, w_i)

        if hasattr(layernorm, "bias"):
            if linear.bias is None:
                linear.bias = torch.nn.Parameter(torch.zeros(linear.out_features, dtype=torch.float64).to(W_))
            linear.bias.data = linear.bias.data.double() + torch.matmul(
                W_.view(w_o, -1, size), layernorm.bias.double()
            ).sum(dim=-1)
            linear.bias.data = linear.bias.data.to(linear_dtype)

    layernorm.weight.data = torch.ones_like(layernorm.weight.data)
    if hasattr(layernorm, "bias"):
        layernorm.bias.data = torch.zeros_like(layernorm.bias.data)


def bake_mean_into_linear(linear: torch.nn.Linear) -> None:
    """
    This function takes a linear layer and subtracts the means from the
    weights and biases. This will result in the linear layer performing
    the mean substitution which is usually done inside layernorm.
    """
    linear_dtype = linear.weight.dtype
    W_ = linear.weight.data.double()
    linear.weight.data = W_ - W_.mean(dim=-2, keepdim=True)
    linear.weight.data = linear.weight.data.to(linear_dtype)
    if linear.bias is not None:
        b_ = linear.bias.data.double()
        linear.bias.data = b_ - b_.mean()
        linear.bias.data = linear.bias.data.to(linear_dtype)


def fuse_deepstack_linear(model):
    for layer in model.visual.deepstack_merger_list:
        fuse_merger_linear(layer.norm, [layer.linear_fc1])
        rms_weight_size = layer.norm.weight.shape[0]
        model_utils.replace_modules(
            layer, torch.nn.LayerNorm, lambda x: model_utils.Qwen3RMSNorm(rms_weight_size, eps=x.eps), False
        )


@torch.no_grad()
def fuse_layer_norms(model, device=None, llm_rotate=True):
    model_type = model_utils.get_model_type(model)

    kwargs = {"model": model, "model_type": model_type}

    # Embedding fusion
    for W in model_utils.get_embeddings(**kwargs):
        if model_type in [
            model_utils.LLAMA_MODEL,
            model_utils.QWEN_MODEL,
            model_utils.QWEN2_5_VL_MODEL,
            model_utils.QWEN3_MODEL,
            model_utils.QWEN3_VL_MODEL,
            model_utils.QWEN3_VL_MOE_MODEL,
        ]:
            continue
        W_ = W.weight.data.double()
        W.weight.data = (W_ - W_.mean(dim=-1, keepdim=True)).to(W.weight.data.dtype)

    # visual part
    if model_type == model_utils.QWEN2_5_VL_MODEL:
        # fuse visual ln
        for layer in model.visual.blocks:
            fuse_ln_linear(layer.norm1, [layer.attn.qkv])
            layer.norm1.weight.fill_(1.0)
            fuse_ln_linear(layer.norm2, [layer.mlp.gate_proj, layer.mlp.up_proj])
            layer.norm2.weight.fill_(1.0)
        fuse_merger_linear(model.visual.merger.ln_q, [model.visual.merger.mlp[0]])
        model.visual.merger.ln_q.weight.fill_(1.0)
    elif model_type == model_utils.QWEN3_VL_MODEL or model_type == model_utils.QWEN3_VL_MOE_MODEL:
        bake_mean_into_conv(model.visual.patch_embed.proj)

        for layer in model.visual.blocks:
            fuse_ln_linear(layer.norm1, [layer.attn.qkv])
            fuse_ln_linear(layer.norm2, [layer.mlp.linear_fc1])

            bake_mean_into_linear(layer.attn.proj)
            bake_mean_into_linear(layer.mlp.linear_fc2)

        model_utils.replace_modules(
            model.visual.blocks,
            torch.nn.LayerNorm,
            lambda x: model_utils.Qwen3RMSNorm(x.weight.shape[0], eps=x.eps),
            False,
        )

        fuse_merger_linear(model.visual.merger.norm, [model.visual.merger.linear_fc1])

        model_utils.replace_modules(
            model.visual.merger,
            torch.nn.LayerNorm,
            lambda x: model_utils.Qwen3RMSNorm(x.weight.shape[0], eps=x.eps),
            False,
        )

        fuse_deepstack_linear(model)

    if not llm_rotate:
        print("Not fusing layernorms for llm part")
        return

    # language part.
    layers = model_utils.get_transformer_layers(**kwargs)
    # Fuse the linear operations in Layernorm into the adjacent linear blocks.
    progress_bar = tqdm.tqdm(layers)
    progress_bar.set_description("Fusing layernorms")
    for layer in progress_bar:
        # fuse the input layernorms into the linear layers
        if model_type == model_utils.LLAMA_MODEL:
            fuse_ln_linear(layer.post_attention_layernorm, [layer.mlp.up_proj, layer.mlp.gate_proj])
            fuse_ln_linear(
                layer.input_layernorm,
                [
                    layer.self_attn.q_proj,
                    layer.self_attn.k_proj,
                    layer.self_attn.v_proj,
                ],
            )
        elif model_type in [
            model_utils.QWEN_MODEL,
            model_utils.QWEN3_MODEL,
            model_utils.QWEN2_5_VL_MODEL,
            model_utils.QWEN3_VL_MODEL,
        ]:
            fuse_ln_linear(layer.post_attention_layernorm, [layer.mlp.up_proj, layer.mlp.gate_proj])
            fuse_ln_linear(
                layer.input_layernorm,
                [
                    layer.self_attn.q_proj,
                    layer.self_attn.k_proj,
                    layer.self_attn.v_proj,
                ],
            )
        elif model_type in [model_utils.GLM4V_MODEL]:
            fuse_ln_linear(layer.post_attention_layernorm, [layer.mlp.gate_up_proj])
            fuse_ln_linear(
                layer.input_layernorm,
                [
                    layer.self_attn.q_proj,
                    layer.self_attn.k_proj,
                    layer.self_attn.v_proj,
                ],
            )

        elif model_type == model_utils.OPT_MODEL:
            fuse_ln_linear(
                layer.self_attn_layer_norm,
                [
                    layer.self_attn.q_proj,
                    layer.self_attn.k_proj,
                    layer.self_attn.v_proj,
                ],
            )
            fuse_ln_linear(layer.final_layer_norm, [layer.fc1])
        elif model_type in [
            model_utils.QWEN3_VL_MOE_MODEL,
        ]:
            fuse_ln_linear(layer.post_attention_layernorm, [layer.mlp.experts.gate_up_proj])
            fuse_ln_linear(
                layer.input_layernorm,
                [
                    layer.self_attn.q_proj,
                    layer.self_attn.k_proj,
                    layer.self_attn.v_proj,
                ],
            )
        else:
            raise ValueError(f"Unknown model type {model_type}")

        # layer.post_attention_layernorm.fuse_weight = True
        layer.post_attention_layernorm.weight.fill_(1.0)
        # layer.input_layernorm.fuse_weight = True
        layer.input_layernorm.weight.fill_(1.0)

        if model_type == model_utils.OPT_MODEL:
            bake_mean_into_linear(layer.self_attn.out_proj)
            bake_mean_into_linear(layer.fc2)

    fuse_ln_linear(
        model_utils.get_pre_head_layernorm(**kwargs),
        [model_utils.get_lm_head(**kwargs)],
    )
    if model_type in [
        model_utils.QWEN2_5_VL_MODEL,
        model_utils.QWEN3_VL_MODEL,
        model_utils.QWEN3_VL_MOE_MODEL,
        model_utils.GLM4V_MODEL,
    ]:
        model.language_model.norm.weight.fill_(1.0)
    else:
        model.model.norm.weight.fill_(1.0)


def random_orthogonal_matrix(size, device):
    """
    Generate a random orthogonal matrix of the specified size.
    First, we generate a random matrix with entries from a standard distribution.
    Then, we use QR decomposition to obtain an orthogonal matrix.
    Finally, we multiply by a diagonal matrix with diag r to adjust the signs.

    Args:
    size (int): The size of the matrix (size x size).

    Returns:
    torch.Tensor: An orthogonal matrix of the specified size.
    """
    torch.cuda.empty_cache()
    random_matrix = torch.randn(size, size, dtype=torch.float64).to(device)
    q, r = torch.linalg.qr(random_matrix)
    q *= torch.sign(torch.diag(r)).unsqueeze(0)
    return q


def get_orthogonal_matrix(size, mode, device=torch.device("cuda")):
    if mode == "random":
        return random_orthogonal_matrix(size, device)
    elif mode == "hadamard":
        return random_hadamard_matrix(size, device)
    else:
        raise ValueError(f"Unknown mode {mode}")


def rotate_visual_merger(model, Q: torch.Tensor) -> None:
    # Rotate the head.
    dtype = model.visual.merger.mlp[0].weight.dtype

    q_shape = Q.shape[0]
    o_shape, i_shape = model.visual.merger.mlp[0].weight.shape

    W_ = model.visual.merger.mlp[0].weight.to(dtype=torch.float64).reshape(o_shape, -1, q_shape)
    model.visual.merger.mlp[0].weight.data = torch.matmul(W_, Q).to(dtype=dtype).reshape(o_shape, i_shape).contiguous()


def rotate_qwen3_vl_visual_merger(model, Q: torch.Tensor) -> None:
    # Rotate the head.
    dtype = model.visual.merger.linear_fc1.weight.dtype

    q_shape = Q.shape[0]
    o_shape, i_shape = model.visual.merger.linear_fc1.weight.shape

    W_ = model.visual.merger.linear_fc1.weight.to(dtype=torch.float64).reshape(o_shape, -1, q_shape)
    model.visual.merger.linear_fc1.weight.data = (
        torch.matmul(W_, Q).to(dtype=dtype).reshape(o_shape, i_shape).contiguous()
    )


def rotate_qwen3_vl_deepstack_merger(model, Q: torch.Tensor) -> None:
    for layer in model.visual.deepstack_merger_list:
        dtype = layer.linear_fc1.weight.dtype
        q_shape = Q.shape[0]
        o_shape, i_shape = layer.linear_fc1.weight.shape
        W_ = layer.linear_fc1.weight.to(dtype=torch.float64).reshape(o_shape, -1, q_shape)
        layer.linear_fc1.weight.data = torch.matmul(W_, Q).to(dtype=dtype).reshape(o_shape, i_shape).contiguous()


def rotate_embeddings(model, Q: torch.Tensor) -> None:
    # Rotate the embeddings.
    model_type = model_utils.model_type_extractor(model)
    for W in model_utils.get_embeddings(model, model_type):
        raw_device = W.weight.device
        W = W.to(Q.device)
        dtype = W.weight.data.dtype
        W_ = W.weight.data.to(dtype=torch.float64)
        if W_.shape[-1] != Q.shape[0]:
            origin_shape = W_.shape
            W_ = W_.reshape(-1, Q.shape[0])
            W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).to(raw_device).reshape(origin_shape)
        else:
            W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).to(raw_device)
    if model_type == model_utils.QWEN2_5_VL_MODEL:
        Q = Q.to(model.visual.merger.mlp[2].weight.device)
        W_ = model.visual.merger.mlp[2].weight.data.to(dtype=torch.float64)
        model.visual.merger.mlp[2].weight.data = torch.matmul(Q.T, W_).to(dtype=dtype)
        if model.visual.merger.mlp[2].bias is not None:
            b = model.visual.merger.mlp[2].bias.data.to(dtype=torch.float64)
            model.visual.merger.mlp[2].bias.data = torch.matmul(b, Q).to(dtype=dtype)
    if model_type == model_utils.QWEN3_VL_MODEL or model_type == model_utils.QWEN3_VL_MOE_MODEL:
        Q = Q.to(model.visual.merger.linear_fc2.weight.device)
        W_ = model.visual.merger.linear_fc2.weight.data.to(dtype=torch.float64)
        model.visual.merger.linear_fc2.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype)
        if model.visual.merger.linear_fc2.bias is not None:
            b = model.visual.merger.linear_fc2.bias.data.to(dtype=torch.float64)
            model.visual.merger.linear_fc2.bias.data = torch.matmul(b, Q).to(dtype=dtype)

        for layer in model.visual.deepstack_merger_list:
            Q = Q.to(layer.linear_fc2.weight.device)
            W_ = layer.linear_fc2.weight.data.to(dtype=torch.float64)
            layer.linear_fc2.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype)
            if layer.linear_fc2.bias is not None:
                b = layer.linear_fc2.bias.data.to(dtype=torch.float64)
                layer.linear_fc2.bias.data = torch.matmul(b, Q).to(dtype=dtype)


def _rotate_linear_lora_input(linear, Q: torch.Tensor):
    """Apply input-side rotation to LoRA A branch: A <- A @ Q."""
    if not hasattr(linear, "weight_lora_a"):
        return

    lora_a = getattr(linear, "weight_lora_a")
    if lora_a is None:
        return

    lora_dtype = lora_a.dtype
    lora_device = lora_a.device
    q = Q.to(lora_device)
    a = lora_a.to(dtype=torch.float64)
    if a.shape[-1] != q.shape[0]:
        return
    a = torch.matmul(a, q).to(dtype=lora_dtype)
    setattr(linear, "weight_lora_a", a)


def _rotate_linear_lora_output(linear, Q: torch.Tensor):
    """Apply output-side rotation to LoRA B branch: B <- Q^T @ B."""
    if not hasattr(linear, "weight_lora_b"):
        return

    lora_b = getattr(linear, "weight_lora_b")
    if lora_b is None:
        return

    lora_dtype = lora_b.dtype
    lora_device = lora_b.device
    q = Q.to(lora_device)
    b = lora_b.to(dtype=torch.float64)
    if b.shape[0] != q.shape[0]:
        return
    b = torch.matmul(q.T, b).to(dtype=lora_dtype)
    setattr(linear, "weight_lora_b", b)


def rotate_attention_inputs(layer, Q, model_type) -> None:
    # Rotate the WQ, WK and WV matrices of the self-attention layer.
    try:
        layer_list = [layer.self_attn.q_proj, layer.self_attn.k_proj, layer.self_attn.v_proj]
    except:
        layer_list = [layer.attn.qkv]
    for W in layer_list:
        dtype = W.weight.dtype
        W_ = W.weight.to(dtype=torch.float64)
        if W_.shape[-1] != Q.shape[0]:
            origin_shape = W_.shape
            W_ = W_.reshape(-1, Q.shape[0])
            W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).reshape(origin_shape)
        else:
            W.weight.data = torch.matmul(W_, Q).to(dtype=dtype)
        _rotate_linear_lora_input(W, Q)


def rotate_attention_output(layer, Q, model_type) -> None:
    # Rotate output matrix of the self-attention layer.
    if model_type == model_utils.LLAMA_MODEL:
        W = layer.self_attn.o_proj
    elif model_type == model_utils.OPT_MODEL:
        W = layer.self_attn.out_proj
    elif model_type == model_utils.QWEN_MODEL or model_type == model_utils.QWEN3_MODEL:
        W = layer.self_attn.o_proj
    elif model_type in [
        model_utils.QWEN2_5_VL_MODEL,
        model_utils.QWEN3_VL_MODEL,
        model_utils.QWEN3_VL_MOE_MODEL,
        model_utils.GLM4V_MODEL,
    ]:
        try:
            W = layer.attn.proj
        except:
            W = layer.self_attn.o_proj
    else:
        raise ValueError(f"Unknown model type {model_type}")

    dtype = W.weight.data.dtype
    W_ = W.weight.data.to(dtype=torch.float64)
    if Q.shape[0] != W_.shape[0]:
        origin_shape = W_.shape
        W_ = W_.reshape(Q.shape[0], -1)
        W.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype).reshape(origin_shape)
    else:
        W.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype)

    if W.bias is not None:
        b = W.bias.data.to(dtype=torch.float64)
        if Q.shape[0] != b.shape[0]:
            origin_shape = b.shape
            b = b.reshape(Q.shape[0], -1)
            W.bias.data = torch.matmul(Q.T, b).to(dtype=dtype).reshape(origin_shape)
        else:
            W.bias.data = torch.matmul(Q.T, b).to(dtype=dtype)
    _rotate_linear_lora_output(W, Q)


def rotate_mlp_input(layer, Q, model_type):
    # Rotate the MLP input weights.
    if model_type == model_utils.LLAMA_MODEL:
        mlp_inputs = [layer.mlp.up_proj, layer.mlp.gate_proj]
    elif model_type == model_utils.OPT_MODEL:
        mlp_inputs = [layer.fc1]
    elif model_type in [model_utils.QWEN_MODEL, model_utils.QWEN3_MODEL, model_utils.QWEN2_5_VL_MODEL]:
        mlp_inputs = [layer.mlp.up_proj, layer.mlp.gate_proj]
    elif model_type == model_utils.GLM4V_MODEL:
        mlp_inputs = [layer.mlp.gate_up_proj]
    elif model_type == model_utils.QWEN3_VL_MODEL or model_type == model_utils.QWEN3_VL_MOE_MODEL:
        try:
            mlp_inputs = [layer.mlp.linear_fc1]
            llm_part = False
        except:
            if model_type == model_utils.QWEN3_VL_MOE_MODEL:
                mlp_inputs = [layer.mlp.experts.gate_up_proj, layer.mlp.gate]
            else:
                mlp_inputs = [layer.mlp.up_proj, layer.mlp.gate_proj]
            llm_part = True
    else:
        raise ValueError(f"Unknown model type {model_type}")

    for W in mlp_inputs:
        # if model_type == model_utils.QWEN3_VL_MOE_MODEL and llm_part:
        try:
            dtype = W.dtype
            W_ = W.data.to(dtype=torch.float64)
        except:
            dtype = W.weight.dtype
            W_ = W.weight.data.to(dtype=torch.float64)
        if W_.shape[-1] != Q.shape[0]:
            if model_type == model_utils.QWEN3_VL_MOE_MODEL and llm_part:
                W.data = torch.matmul(Q.T, W_).to(dtype=dtype)
                # origin_shape = W_.shape
                # W_ = W_.reshape(-1, Q.shape[0])
                # W.data = torch.matmul(W_, Q).to(dtype=dtype).reshape(origin_shape)
            else:
                origin_shape = W_.shape
                W_ = W_.reshape(-1, Q.shape[0])
                W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).reshape(origin_shape)
        else:
            W.weight.data = torch.matmul(W_, Q).to(dtype=dtype)
        _rotate_linear_lora_input(W, Q)


def rotate_mlp_output(layer, Q, model_type):
    # Rotate the MLP output weights and bias.
    if model_type == model_utils.LLAMA_MODEL:
        W = layer.mlp.down_proj
    elif model_type == model_utils.OPT_MODEL:
        W = layer.fc2
    elif model_type in (
        model_utils.QWEN_MODEL,
        model_utils.QWEN3_MODEL,
        model_utils.QWEN2_5_VL_MODEL,
        model_utils.GLM4V_MODEL,
    ):
        W = layer.mlp.down_proj
    elif model_type == model_utils.QWEN3_VL_MODEL or model_type == model_utils.QWEN3_VL_MOE_MODEL:
        try:
            W = layer.mlp.linear_fc2
            llm_part = False
        except:
            if model_type == model_utils.QWEN3_VL_MOE_MODEL:
                W = layer.mlp.experts.down_proj
            else:
                W = layer.mlp.down_proj
            llm_part = True
    else:
        raise ValueError(f"Unknown model type {model_type}")
    if model_type == model_utils.QWEN3_VL_MOE_MODEL and llm_part:
        dtype = W.dtype
        W_ = W.data.to(dtype=torch.float64)
    else:
        dtype = W.weight.dtype
        W_ = W.weight.data.to(dtype=torch.float64)
    if Q.shape[0] != W_.shape[0]:
        if model_type == model_utils.QWEN3_VL_MOE_MODEL and llm_part:
            W.data = torch.matmul(W_, Q).to(dtype=dtype)
            # origin_shape = W_.shape
            # W_ = W_.reshape(Q.shape[0], -1)
            # W.data = torch.matmul(Q.T, W_).to(dtype=dtype).reshape(origin_shape)
        else:
            origin_shape = W_.shape
            W_ = W_.reshape(Q.shape[0], -1)
            W.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype).reshape(origin_shape)
    else:
        W.weight.data = torch.matmul(Q.T, W_).to(dtype=dtype)
    if hasattr(W, "bias"):
        if W.bias is not None:
            b = W.bias.data.to(dtype=torch.float64)
            if Q.shape[0] != b.shape[0]:
                origin_shape = b.shape
                b = b.reshape(Q.shape[0], -1)
                W.bias.data = torch.matmul(Q.T, b).to(dtype=dtype).reshape(origin_shape)
            else:
                W.bias.data = torch.matmul(Q.T, b).to(dtype=dtype)
    _rotate_linear_lora_output(W, Q)


def matmul_hadU_cuda_had(X, hadK, transpose=False):
    """
    Apply hadamard transformation.
    It reshapes X and applies Walsh-Hadamard transform to the last dimension.
    Then, it will multiply the retult by another hadamard matrix.
    """
    from fast_hadamard_transform import hadamard_transform
    from hadamard_utils import get_had172

    n = X.shape[-1]
    K = hadK.shape[-1]

    if transpose:
        hadK = hadK.T.contiguous()
    input = X.float().cuda().view(-1, K, n // K)
    input = hadamard_transform(input.contiguous(), scale=1 / math.sqrt(n))
    input = hadK.to(input.device).to(input.dtype) @ input
    return input.to(X.device).to(X.dtype).reshape(X.shape)


def rotate_conv(layer, Q_v, embed_dims):
    dtype = layer.weight.dtype
    weight_shape = layer.weight.data.shape
    layer.weight.data = (
        torch.matmul(Q_v.T, layer.weight.data.double().view(embed_dims, -1)).to(dtype).view(weight_shape)
    )
    if layer.bias is not None:
        layer.bias.data = torch.matmul(layer.bias.data.double(), Q_v).to(dtype)


def rotate_faster_down_proj(layer, model_type, hardK):
    from fast_hadamard_transform import hadamard_transform

    if model_type == model_utils.LLAMA_MODEL:
        W = layer.mlp.down_proj
    else:
        raise ValueError(f"Faster MLP is onlu supported for LLaMa models!")

    dtype = W.weight.data.dtype
    W.weight.data = matmul_hadU_cuda_had(W.weight.data.float().cuda(), hardK)
    W.weight.data = W.weight.data.to(device="cpu", dtype=dtype)


def rotate_head(model, Q: torch.Tensor) -> None:
    # Rotate the head.
    W = model_utils.get_lm_head(model, model_type=model_utils.model_type_extractor(model))
    raw_device = W.weight.device
    W = W.to(Q.device)
    dtype = W.weight.data.dtype
    W_ = W.weight.data.to(dtype=torch.float64)
    if W_.shape[-1] != Q.shape[0]:
        origin_shape = W_.shape
        W_ = W_.reshape(-1, Q.shape[0])
        W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).to(raw_device).reshape(origin_shape)
    else:
        W.weight.data = torch.matmul(W_, Q).to(dtype=dtype).to(raw_device)


def rotate_ov_proj(layer, model_type, head_num, head_dim):
    v_proj = layer.self_attn.v_proj
    if model_type == model_utils.LLAMA_MODEL:
        o_proj = layer.self_attn.o_proj
    elif model_type == model_utils.OPT_MODEL:
        o_proj = layer.self_attn.out_proj
    elif model_type == model_utils.QWEN_MODEL or model_type == model_utils.QWEN3_MODEL:
        o_proj = layer.self_attn.o_proj
    else:
        raise ValueError(f"Unknown model type {model_type}")


def rotate_visual_patch_pos_embed(model, Q_v: torch.Tensor):
    model.visual.pos_embed.weight.data = torch.matmul(model.visual.pos_embed.weight.data.double(), Q_v).to(
        model.visual.pos_embed.weight.dtype
    )


@torch.inference_mode()
def rotate_model(model, rotate_mode, device, quarot_matrix_size=None, llm_rotate=True):
    model_type = model_utils.get_model_type(model)
    if model_type == model_utils.QWEN2_5_VL_MODEL:
        num_heads = model.visual.blocks[0].attn.num_heads
        # head_dim = model.visual.blocks[0].attn.qkv.in_features // num_heads
        Q_v = get_orthogonal_matrix(model.visual.blocks[0].attn.qkv.in_features, rotate_mode)

        rotate_conv(
            model.visual.patch_embed.proj,
            Q_v,
            model.visual.blocks[0].attn.qkv.in_features,
        )

        for idx, layer in enumerate(
            tqdm.tqdm(
                model.visual.blocks,
                unit="layer",
                desc="rotating visual layers",
            )
        ):
            rotate_attention_inputs(layer, Q_v, model_type)
            rotate_attention_output(layer, Q_v, model_type)
            rotate_mlp_input(layer, Q_v, model_type)
            rotate_mlp_output(layer, Q_v, model_type)
        rotate_visual_merger(model, Q_v)
        model_utils.cleanup_memory()
    elif model_type == model_utils.QWEN3_VL_MODEL or model_type == model_utils.QWEN3_VL_MOE_MODEL:
        raw_device = next(model.visual.parameters()).device
        model.visual.to(device)

        num_heads = model.visual.blocks[0].attn.num_heads
        head_dim = model.visual.blocks[0].attn.qkv.in_features // num_heads
        Q_v = get_orthogonal_matrix(model.visual.blocks[0].attn.qkv.in_features, rotate_mode)

        rotate_conv(
            model.visual.patch_embed.proj,
            Q_v,
            model.visual.blocks[0].attn.qkv.in_features,
        )

        rotate_visual_patch_pos_embed(model, Q_v)

        for idx, layer in enumerate(
            tqdm.tqdm(
                model.visual.blocks,
                unit="layer",
                desc="Rotating Qwen3 VL Visual",
            )
        ):
            rotate_attention_inputs(layer, Q_v, model_type)
            rotate_attention_output(layer, Q_v, model_type)
            rotate_mlp_input(layer, Q_v, model_type)
            rotate_mlp_output(layer, Q_v, model_type)

        rotate_qwen3_vl_visual_merger(model, Q_v)
        rotate_qwen3_vl_deepstack_merger(model, Q_v)
        model.visual.to(raw_device)
        model_utils.cleanup_memory()

    if not llm_rotate:
        model._quarot_rotation_matrix = None
        return

    llm_hidden_size = (
        model.config.hidden_size
        if (
            model_type != model_utils.QWEN3_VL_MODEL
            and model_type != model_utils.QWEN3_VL_MOE_MODEL
            and model_type != model_utils.GLM4V_MODEL
        )
        else model.config.text_config.hidden_size
    )

    if quarot_matrix_size is None:
        Q = get_orthogonal_matrix(llm_hidden_size, rotate_mode, device=device)
    else:
        Q = torch.zeros(
            [llm_hidden_size, llm_hidden_size],
            dtype=torch.float64,
            device=device,
            requires_grad=False,
        )
        assert int(llm_hidden_size / quarot_matrix_size) * quarot_matrix_size == llm_hidden_size, "not fully dividen"
        for i in range(0, llm_hidden_size, quarot_matrix_size):
            local_Q = get_orthogonal_matrix(quarot_matrix_size, rotate_mode, device=device)
            Q[i : i + quarot_matrix_size, i : i + quarot_matrix_size] = local_Q

    # Cache rotation matrix for downstream modality adapters (e.g., audio projector).
    model._quarot_rotation_matrix = Q.detach().cpu()

    config = model.config
    num_heads = (
        config.num_attention_heads
        if (
            model_type != model_utils.QWEN3_VL_MODEL
            and model_type != model_utils.QWEN3_VL_MOE_MODEL
            and model_type != model_utils.GLM4V_MODEL
        )
        else config.text_config.num_attention_heads
    )
    model_dim = (
        config.hidden_size
        if (
            model_type != model_utils.QWEN3_VL_MODEL
            and model_type != model_utils.QWEN3_VL_MOE_MODEL
            and model_type != model_utils.GLM4V_MODEL
        )
        else config.text_config.hidden_size
    )
    if (
        model_type != model_utils.QWEN3_VL_MODEL
        and model_type != model_utils.QWEN3_VL_MOE_MODEL
        and model_type != model_utils.GLM4V_MODEL
    ):
        head_dim = model_dim // num_heads
    else:
        if not hasattr(model.config.text_config, "head_dim"):
            head_dim = model_dim // num_heads
        else:
            head_dim = model.config.text_config.head_dim

    model_type = model_utils.model_type_extractor(model)
    rotate_embeddings(model, Q)
    rotate_head(model, Q)
    model_utils.cleanup_memory()

    layers = model_utils.get_transformer_layers(model, model_type=model_type)
    for idx, layer in enumerate(tqdm.tqdm(layers, unit="layer", desc="Rotating")):
        raw_device = next(layer.parameters()).device
        # Move layer to target device in-place
        layer.to(device)
        rotate_attention_inputs(layer, Q, model_type)
        rotate_attention_output(layer, Q, model_type)
        rotate_mlp_input(layer, Q, model_type)
        rotate_mlp_output(layer, Q, model_type)
        # Move layer back to original device in-place
        layer.to(raw_device)
        # rotate_ov_proj(layers[idx], model_type, num_heads, head_dim)
    model_utils.cleanup_memory()
    return Q


@torch.inference_mode
def online_rotate(module, inp):
    x = torch.nn.functional.linear(inp[0], module.Q)
    return (x,) + inp[1:]


def register_online_rotation(module, Q: torch.Tensor):
    assert not hasattr(module, "Q")
    # Note F.linear(x, A) performs x@A.T
    module.register_buffer("Q", Q.T.to(module.weight.data))

    # We use forward_pre_hook because we capture the input using forward_hook, which could then capture the rotated input.
    # If we implement in the forward() the un-rotated original input will be captured.
    module.rotate_handle = module.register_forward_pre_hook(online_rotate)


class QKRotationWrapper(torch.nn.Module):
    def __init__(self, func, config, *args, **kwargs):
        super().__init__()
        self.config = config
        num_heads = config.num_attention_heads
        model_dim = config.hidden_size
        head_dim = model_dim // num_heads
        assert is_pow2(head_dim), f"Only power of 2 head_dim is supported for K-cache Quantization!"
        self.func = func
        self.k_quantizer = quant_utils.ActQuantizer()
        self.k_bits = 16
        if kwargs is not None:
            assert kwargs["k_groupsize"] in [
                -1,
                head_dim,
            ], f"Only token-wise/{head_dim}g quantization is supported for K-cache"
            self.k_bits = kwargs["k_bits"]
            self.k_groupsize = kwargs["k_groupsize"]
            self.k_sym = kwargs["k_sym"]
            self.k_clip_ratio = kwargs["k_clip_ratio"]
            self.k_quantizer.configure(
                bits=self.k_bits,
                groupsize=-1,  # we put -1 to be toke-wise quantization and handle head-wise quantization by ourself
                sym=self.k_sym,
                clip_ratio=self.k_clip_ratio,
            )

    def forward(self, *args, **kwargs):
        q, k = self.func(*args, **kwargs)
        dtype = q.dtype
        q = hadamard_transform(q.float(), scale=1 / math.sqrt(q.shape[-1])).to(dtype)
        k = hadamard_transform(k.float(), scale=1 / math.sqrt(k.shape[-1])).to(dtype)
        (bsz, num_heads, seq_len, head_dim) = k.shape

        if self.k_groupsize == -1:  # token-wise quantization
            token_wise_k = k.transpose(1, 2).reshape(-1, self.config.hidden_size)
            self.k_quantizer.find_params(token_wise_k)
            k = self.k_quantizer(token_wise_k).reshape((bsz, seq_len, num_heads, head_dim)).transpose(1, 2).to(q)
        else:  # head-wise quantization
            per_head_k = k.view(-1, head_dim)
            self.k_quantizer.find_params(per_head_k)
            k = self.k_quantizer(per_head_k).reshape((bsz, num_heads, seq_len, head_dim)).to(q)

        self.k_quantizer.free()

        return q, k


def add_qk_rotation_wrapper_after_function_call_in_forward(module, function_name, *args, **kwargs):
    """
    This function adds a rotation wrapper after the output of a function call in forward.
    Only calls directly in the forward function are affected. calls by other functions called in forward are not affected.
    """
    import functools

    import monkeypatch

    attr_name = f"{function_name}_qk_rotation_wrapper"
    assert not hasattr(module, attr_name)
    wrapper = monkeypatch.add_wrapper_after_function_call_in_method(
        module,
        "forward",
        function_name,
        functools.partial(QKRotationWrapper, *args, **kwargs),
    )
    setattr(module, attr_name, wrapper)


@torch.no_grad()
def quarot(model, rotate_mode="hadamard", device=torch.device("cuda"), quarot_matrix_size=None):
    model_utils.cleanup_memory(verbose=True)

    # fuse layernorm
    fuse_layer_norms(model)

    # rotation
    rotate_model(model, rotate_mode, device=device, quarot_matrix_size=quarot_matrix_size)

    model_utils.cleanup_memory(verbose=True)
    # model.to(device)
    return model
